<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-08-16 12:31:20 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
INFO - 2023-08-16 12:31:21 --> Config Class Initialized
INFO - 2023-08-16 12:31:21 --> Hooks Class Initialized
DEBUG - 2023-08-16 12:31:21 --> UTF-8 Support Enabled
INFO - 2023-08-16 12:31:21 --> Utf8 Class Initialized
INFO - 2023-08-16 12:31:22 --> URI Class Initialized
DEBUG - 2023-08-16 12:31:22 --> No URI present. Default controller set.
INFO - 2023-08-16 12:31:22 --> Router Class Initialized
INFO - 2023-08-16 12:31:22 --> Output Class Initialized
INFO - 2023-08-16 12:31:22 --> Security Class Initialized
DEBUG - 2023-08-16 12:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 12:31:22 --> Input Class Initialized
INFO - 2023-08-16 12:31:22 --> Language Class Initialized
INFO - 2023-08-16 12:31:23 --> Loader Class Initialized
INFO - 2023-08-16 12:31:23 --> Helper loaded: url_helper
INFO - 2023-08-16 12:31:23 --> Helper loaded: string_helper
INFO - 2023-08-16 12:31:23 --> Helper loaded: file_helper
DEBUG - 2023-08-16 12:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 12:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 12:31:24 --> Controller Class Initialized
DEBUG - 2023-08-16 12:31:24 --> IMAP class is loaded.
DEBUG - 2023-08-16 12:31:24 --> Config file loaded: C:\laragon\www\webmail-ci-and-jquery\application\config/email_config.php
DEBUG - 2023-08-16 12:31:24 --> PHPMailer class is loaded.
ERROR - 2023-08-16 12:31:24 --> Severity: error --> Exception: Class 'Ddeboer\Imap\Server' not found C:\laragon\www\webmail-ci-and-jquery\application\libraries\IMAP_Library.php 23
ERROR - 2023-08-16 12:31:25 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
INFO - 2023-08-16 12:31:25 --> Config Class Initialized
INFO - 2023-08-16 12:31:25 --> Hooks Class Initialized
DEBUG - 2023-08-16 12:31:25 --> UTF-8 Support Enabled
INFO - 2023-08-16 12:31:25 --> Utf8 Class Initialized
INFO - 2023-08-16 12:31:25 --> URI Class Initialized
INFO - 2023-08-16 12:31:25 --> Router Class Initialized
INFO - 2023-08-16 12:31:25 --> Output Class Initialized
INFO - 2023-08-16 12:31:25 --> Security Class Initialized
DEBUG - 2023-08-16 12:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 12:31:25 --> Input Class Initialized
INFO - 2023-08-16 12:31:25 --> Language Class Initialized
ERROR - 2023-08-16 12:31:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2023-08-16 12:32:18 --> Could not find the specified $config['composer_autoload'] path: ./vendor/autoload.php
INFO - 2023-08-16 12:32:18 --> Config Class Initialized
INFO - 2023-08-16 12:32:18 --> Hooks Class Initialized
DEBUG - 2023-08-16 12:32:18 --> UTF-8 Support Enabled
INFO - 2023-08-16 12:32:18 --> Utf8 Class Initialized
INFO - 2023-08-16 12:32:18 --> URI Class Initialized
DEBUG - 2023-08-16 12:32:18 --> No URI present. Default controller set.
INFO - 2023-08-16 12:32:18 --> Router Class Initialized
INFO - 2023-08-16 12:32:18 --> Output Class Initialized
INFO - 2023-08-16 12:32:18 --> Security Class Initialized
DEBUG - 2023-08-16 12:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-16 12:32:18 --> Input Class Initialized
INFO - 2023-08-16 12:32:18 --> Language Class Initialized
INFO - 2023-08-16 12:32:18 --> Loader Class Initialized
INFO - 2023-08-16 12:32:18 --> Helper loaded: url_helper
INFO - 2023-08-16 12:32:18 --> Helper loaded: string_helper
INFO - 2023-08-16 12:32:18 --> Helper loaded: file_helper
DEBUG - 2023-08-16 12:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-08-16 12:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-16 12:32:18 --> Controller Class Initialized
DEBUG - 2023-08-16 12:32:18 --> IMAP class is loaded.
DEBUG - 2023-08-16 12:32:18 --> Config file loaded: C:\laragon\www\webmail-ci-and-jquery\application\config/email_config.php
DEBUG - 2023-08-16 12:32:18 --> PHPMailer class is loaded.
ERROR - 2023-08-16 12:32:18 --> Severity: error --> Exception: Class 'Ddeboer\Imap\Server' not found C:\laragon\www\webmail-ci-and-jquery\application\libraries\IMAP_Library.php 23
